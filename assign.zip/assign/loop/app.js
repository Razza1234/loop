// Question 3

// for(var i = 1; i <=10 ; i = i + 1 ){

//         document.write(i +"<br>")
// }

// Question 4

// var tableNumber = +prompt("What No. of Table U Need")
// var tabLength = +prompt("What No. of Length of Table U Need")

// document.write("Table Number : " + tableNumber + " " + "table Length: " + tabLength + "<br>" )
 
// for(var a = 1 ; a <= tabLength ; a++){
//     document.write(tableNumber + " x" + " " + a +" " + "=" + 
//     " " + tableNumber*a + "<br>" )
// }



// COUNTING

// var arr = ("counting:")
// document.write(arr )
 
// for(var a = 1 ; a <= 15 ; a++)
//     document.write(a+"" + "," )


//  Reverse counting

//     var resarr = ("Reverse counting:")
// document.write(resarr +"<br>")
//  function countdown ()
// for(var i = 15 ; i > 1 ; --a)
//     document.write(i+"," +"<br>")


    //  Even

//     var evenarr = ("Even:")
// document.write(evenarr )
 
// function even(){
// for(let e=1;e<=20;e++){
//    if(e%2==0){
//     document.write(e + "" + ",")
//    }
// }
// }
// even();
    

    // Odd

//     var oddarr = ("odd:")
//     document.write(oddarr )
     
//     function odd(){
//     for(let y=1;y<=15;y+=2){
//        if(y%2!==0){
//         document.write(y+ "," )
//     }
// }
// }
// odd();

    
    // Series

//     var serarr = ("series:")
// document.write(serarr )
 
// function even(){
// for(let i=1;i<=20;i++){
//    if(i%2==0){
//     document.write(i + "k")
//    }
// }
// }
// even();

// Question 7

    // var eat = ["cake" , "apple pie" , "cookie" , "chips" , "patties"];

    // var userInput = prompt("What do U liKe ¿?")
    
    // var file = "yep"
    
    // for(var i = 0 ; i < eat.length ; i++){
    
    //         if(userInput === "cake" ){
    //             alert("cake is AVAILABLE")
    //             file = "nop"
    //             break;
    //         }   
    //         else if(userInput === "cookies"){
    //         }   
    // }
    
    // if(file == "yep"){
    //     alert("not available")
    // }


    // Question 8

// var arr = [12 , 24 , 4 , 56 , 59 , 45];
// var largest = arr [2];

// for (let i=0 ; i<arr.length; i++){
//         if (largest < arr[i]){
//                 largest = arr[i]
//         }
// }
// console.log("largest number:" + largest);



// Question 9

// var arr = [12 , 24 , 4 , 56 , 59 , 45];

// var smallest = arr [2];

// for (let i=0 ; i<arr.length; i++){
//         if (smallest > arr[i]){
//                 smallest = arr[i]
//         }
// }
// console.log("smallest number:" + smallest);

// Question 10 

// for(var i = 0; i <=100 ; i = i +5 ){

//         document.write(i+",")
// }

    