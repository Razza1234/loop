// QUestion 7

// var qualification0 = "Qualification"
// var qualification1 = "SSC"
// var qualification2 = "HSC"
// var qualification3 = "BCS"
// var qualification4 = "BCOM"
// var qualification4 = "MS"
// var qualification4 = "M.Phil"
// var qualification4 = "PhD"

// var qualifications = [ "SSC" + "<br>" + +"HSC" + "<br>" + "BCS" + "<br>" +"BCOM" + "<br>" +"PhD" + "<br>" + "M.Phil" + "<br>" + "MS"];

// document.write(qualification0 + "<br>")
// document.write(qualifications)


// QUestion 8

// var Arr = ["Score of Michael is 320. percentage: 64%" + "<br>"+ "Score of John is 230. percentage: 46%" + "<br>"+"Score of Tony is 480. percentage: 96%"  ]

// document.write(Arr)


// QUestion 10

// var arr = ["Score of student:" + 320,230,480,120  ]
// var stuarr = ["Ordered Score of student:" + 120,230,320,480 ]


// document.write(arr + "<br>")
// document.write(stuarr)


// question 12
// var array = "Array:"
// document.write(array+ "<br>" )
// var stdarr = ["This" , "is" , "my" , "cat"]
// document.write(stdarr + "<br>")

// var string = "String:"
// document.write(string + "<br>"  )

// var byarr = ["This is my cat"]
// document.write(byarr )


